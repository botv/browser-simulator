# Browser Simulator
🌎 A wacky browser simulator
